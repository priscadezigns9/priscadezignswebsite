# MY_RULES.md - Your Rules

## MANDATORY OPERATIONAL PROTOCOL (READ BEFORE TOUCHING ANY BRAND PAGE)

🚨 **MANDATORY RULE — READ BEFORE TOUCHING ANY BRAND PAGE** 🚨

Before editing, pushing, or overwriting ANY file on any brand website:

1. Read `SITE_CHANGELOG.md` in the workspace first.
2. Read `EMPIRE_CLIENT_MANDATE.md` for the unified client flow protocols.
3. Check the approved baseline sizes table — never push a smaller version without user confirmation.
3. Backup the current live file to `backups/YYYY-MM-DD/` before overwriting.
4. Log every change to `SITE_CHANGELOG.md` after pushing.
5. No Amazon links on collection/shop buttons — all CTAs go to internal `/shop/` pages.
6. No batch posting — minimum 3–4 hours between posts on all platforms.

If unsure whether a change is safe → **ASK FIRST, push second.**

---

## Brand Guardrails (NON-NEGOTIABLE)

- **Couture Gallery:** ZERO apparel/clothing. Content must focus 100% on Handbags, Purses, Leathercraft, and Hardware Engineering.
- **Quiet Luxury:** ZERO general fashion. Content must focus 100% on Home Decor, Interior Architecture, and Sanctuaries.
- **NehNeh / SeamriteDesigns:** The dedicated hub for High-Fashion, Apparel, and Art.
- **Prisca Dezigns:** The elite flagship. NO sub-brand hashtags, NO Amazon links, NO "nonsense" (text-only posts). Strictly high-level agency and AI architecture.
- **All Niches:** Must receive equal "Alpha" priority. No niche favoritism. Every post must include a high-fidelity visual.
- **Optimal Time Mandate (EFFECTIVE NOW):** I am authorized to choose the posting times for all 18 niches based on global engagement data and audience activity windows. Fixed schedules are replaced by "Optimal Signal Windows."

## EMPIRE POSTING RULE — EFFECTIVE IMMEDIATELY (2026-05-23 18:16 AST)

### Core Mandate
- **Social media (IG, Facebook, TikTok) = DIRECTION ONLY.** Drive all traffic to brand websites.
- **Every post MUST include the brand domain URL** in the caption.
- **Every post MUST mention the Blog AND the Magazine** in the content.
- Website is the destination — it has the magazine, blog, shop, everything for dedicated fans.

### Daily Posting Limits (ALL platforms — IG, Facebook, TikTok)
- **Max 2 image posts per day** (per brand, per platform).
- **Minimum 3–4 hours between any two posts** — NO exceptions.

### Hard Rules (NON-NEGOTIABLE)
- **NO BATCH POSTING. EVER.** 
  - Do not post multiple images at once, even for major events or awards.
  - Space every post 3–4 hours apart minimum.
- **Dreaming Anime IG Incident (2026-05-23):** Account was flagged for batch posting during Crunchyroll Awards. **DO NOT REPEAT THIS.**
- **Breaking news = 1 post only.** Post immediately, then wait 3–4 hours before next post.
- **Every post includes correct brand website URL/redirect.** No wrong URLs.

### Brand Domain & Redirect Mapping (Reference)
- **Dreaming Anime:** dreaminanime.com
- **Sole Prestige:** priscadezigns.org/sole-prestige
- **Glow Protocol:** priscadezigns.org/glow-protocol
- **Essence Elite:** priscadezigns.org/essence-elite
- **The Watch List:** priscadezigns.org/the-watch-list
- **Atelier Gaming:** priscadezigns.org/atelier-gaming
- **Verdant Co.:** priscadezigns.org/verdant-co
- **The Tech Scout HQ:** priscadezigns.org/tech-scout
- **Paw Vault:** priscadezigns.org/paw-vault
- **Quiet Luxury:** priscadezigns.org/quiet-luxury
- **The Autodrome:** priscadezigns.org/the-autodrome
- **The Escapist:** priscadezigns.org/the-escapist
- **Peak Fit:** priscadezigns.org/peak-fit
- **Prime Land Network:** priscadezigns.org/prime-land-network
- **Couture Gallery:** priscadezigns.org/couture-gallery
- **NehNeh:** priscadezigns.org/nehneh
- **Prisca Dezigns:** priscadezigns.org
- **Velloq:** priscadezigns.org/velloq
- **Moblync:** priscadezigns.org/moblync

## Operational Standards

### Critical Workflow
1. **Source/Generate visual** → Save to FB/IG Photos folder.
2. **Wait for user approval** → User reviews and confirms.
3. **Post ONE image only** → Include correct URL + Blog/Magazine mention.
4. **Archive immediately** → Move source to Published_Archive.
5. **Wait 3–4 hours minimum** → Before posting next image.
6. **Never batch.** Ever.

### AI Video Generation & Upload Rules
- **Playability Mandate:** EVERY video must be verified for playability (valid MP4/MOV container) before upload. Unplayable videos = Immediate rejection.
- **Source Constraint:** NEVER take images from the root "FB/IG Photos" folder.
- **Authorized Sources:** ONLY take photos from the **Posted** (`1zZT0TTdYZ9CxhJWdaSZH_HiGUdHQbJ0z`) or **Published_Archive** (`1343hVeVnT7cwG2jAyTZGKFBNInVBNj1c`) sub-folders.
- **Cleanup Mandate:** Once an image from Posted or Published_Archive is used, it MUST be deleted immediately.
- **Staged Area:** Files in the root "FB/IG Photos" folder are for approval/staging only; do not use them for posting.
- **Archiving (New Posts):** Move fresh posts to Published_Archive immediately after posting.

### AI Generation Rules
- **Pollinations (Free):** Default AI platform for all niches except Glow Protocol and Essence Elite.
- **Glow Protocol & Essence Elite ONLY:** Use Claid.ai for premium luxury product photography.
- **Dreaming Anime:** ZERO AI generation. Official anime art or Amazon product shots only.

### Stock Photo Purge
- **NO generic stock photos** (Unsplash, Pexels, Getty) in the intake pipeline.
- All visuals must be AI-generated, official brand assets, or high-fidelity product photos.

### Asian Session Coverage
- When one geographic region's social session is asleep, the next region is awake.
- Schedule posts across 24-hour cycles to maintain brand presence globally.
- Never batch posts for this — space them 3–4 hours apart even across regions.
