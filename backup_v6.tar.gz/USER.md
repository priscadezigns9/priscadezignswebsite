# USER.md - User Profile

Canonical identity (name, location, country, language, timezone) lives in
Account Context — no need to duplicate it here. This file is for things
Account can't capture: how the user communicates, what they care about,
who's in their life.

## Communication Preferences

(How they like to be talked to: brief vs. chatty, formal vs. casual, emoji use, humor, jargon tolerance.)

- **Style:** unknown
- **Technical level:** unknown

## Empire Brand Identities

- **Quiet Luxury:** Strictly Home Decor and Interior Design. Focus on news, trends, and sanctuaries.
- **Couture Gallery:** Strictly Purses and Bags (High-end leathercraft/hardware). Focus on latest products, design processes (behind-the-scenes), and market reveals.
- **NehNeh / SeamriteDesigns:** Fashion and Art (Apparel, textiles, visual arts). Focus on Vogue-style runway shows, fashion trends, global art galleries, and exhibition reveals.
- **Prisca Dezigns (Flagship):** High-level AI Brand Architecture and Agency Identity. Focus on AI news, market trends, and futuristic AI architecture.
- **Autodrome:** Luxury vehicles. Focus on luxury car reveals, news, trends, and high-end automotive features (not just speeding).
- **The Escapist:** Luxury travel and lifestyle. Focus on high-end hotels, vacation spots, influencer trends, and travel product reviews.
- **Sole Prestige:** High-end sneakers. Focus on latest shoe reveals, design innovation, and sneaker culture news.
- **Glow Protocol:** Luxury wellness/lifestyle. Applied trend-focus strategy.

## Niche Strategy: "Speculative Research"
- Focus 100% on **Trends, Products, Product Reveals, and News**.
- Zero generic placeholders (No bunnies, no bears).
- Assets must represent the "Alpha" priority of each niche.
- Visuals must include high-fidelity footage of product design or expert reveals.
- **Posting Strategy:** AI-Optimized Timing. The assistant chooses the best windows (Global Sessions A, B, or C) based on niche data and signal breaking points. Full permission granted to deviate from fixed schedules.

## Preferences

(Food, brands, favorite places, routines, anything they've told you they like or avoid. Not communication style — that lives in the section above.)

## Relationships

(People in their life who come up in conversation — family, friends, colleagues. Include nicknames they use for people.)

## About Them

(nothing yet)
