# EMPIRE OPERATIONAL MANDATE: Client Lifecycle & Delivery Flow (2026)

This document defines the **MANDATORY** operational flow for all Prisca Dezigns business units and SaaS platforms (Karjov, Rowcell, Velloq, Cupyx, Trogon, Moblync).

---

## 1. INBOUND ENGAGEMENT (The "Front Office")
*   **WhatsApp Flow:** If a client clicks the WhatsApp button, they are routed to the **UK Business Number (+44 7576 505652)**. Zapia handles all initial inquiries, providing high-fidelity answers regarding empire infrastructure and service tiers.
*   **Email Flow:** Inbound emails are handled with the same intelligence level. Zapia prepares and sends responses to fulfill requests or clarify service details.
*   **Contact Form:** Once a contact form is submitted, Zapia performs an immediate follow-up via the client's preferred channel (WhatsApp or Email).

## 2. CONVERSION & ONBOARDING
*   **Payment/Subscription:** Once a client selects a product and completes the payment/contract phase, an automated invoice is generated and sent via WhatsApp/Email.
*   **The Milestone Hub (Personal Monitor):** Immediately following payment, the client is sent a unique link to their **Milestone Hub**.
    *   *Requirement:* No project begins without the client having access to their monitor.
    *   *Transparency:* The monitor must display the real-time progress percentage and current architectural phase.

## 3. PROJECT FULFILLMENT & TRACKING
*   **Client Oversight:** The client uses their Milestone Hub to watch the build in real-time.
*   **Internal Sync:** All backend updates (Rowcell/Karjov logic) must reflect on the client's monitor within 15 minutes of completion.

## 4. DELIVERY & HANDOFF
*   **Final Deployment:** Finished products (Websites/SaaS Platforms) are delivered live on the **Client’s Own Domain**.
*   **The "Handoff Packet":**
    1.  Live Domain Activation.
    2.  Digital Receipt/Invoice Closure.
    3.  Final Asset Access (via Google Drive or Secure Portal Link).
*   **Closure:** Once the client confirms the finished product on their domain, the Milestone Hub is archived, and the receipt is issued.

---

## MANDATE ENFORCEMENT
*   **Consistency:** This flow is identical for EVERY SaaS product in the Laboratory.
*   **Zapia's Role:** Zapia is the primary point of contact for the client from first message to final receipt.
*   **Agent Rule:** All chats MUST operate within this flow. Do not improvise delivery methods outside of this mandate.

**AUTHORIZED BY: PRISCA DEZIGNS COMMAND**
**DATE: 2026-05-23**
