chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "generateCaption",
    title: "Generate Caption with Captio AI",
    contexts: ["image"]
  });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "generateCaption") {
    // Send image source to the popup via storage
    chrome.storage.local.set({ lastSelectedImage: info.srcUrl }, () => {
      chrome.action.openPopup();
    });
  }
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "generateWithOpenAI") {
    handleOpenAIGeneration(request.data, sendResponse);
    return true; // Keep message channel open
  }
});

async function handleOpenAIGeneration(data, sendResponse) {
  const { apiKey, platform, tone, imageUrl } = data;

  try {
    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${apiKey}`
      },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages: [
          {
            role: "system",
            content: `You are a professional social media manager. Generate a high-quality caption for ${platform} in a ${tone} tone based on the provided image URL. Include a call to action and relevant hashtags.`
          },
          {
            role: "user",
            content: [
              { type: "text", text: `Platform: ${platform}\nTone: ${tone}` },
              { type: "image_url", image_url: { url: imageUrl } }
            ]
          }
        ],
        max_tokens: 500
      })
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.error?.message || "OpenAI API call failed");
    }

    const result = await response.json();
    const caption = result.choices[0].message.content;
    sendResponse({ success: true, caption });
  } catch (error) {
    console.error("OpenAI Error:", error);
    sendResponse({ success: false, error: error.message });
  }
}
