const PLATFORM_LIMITS = {
  "Instagram": 2200,
  "Twitter": 280,
  "Facebook": 63206,
  "Threads": 500,
  "LinkedIn": 3000
};

let currentHashtags = [];

document.addEventListener('DOMContentLoaded', async () => {
  const elements = {
    imagePreview: document.getElementById('imagePreview'),
    platform: document.getElementById('platform'),
    tone: document.getElementById('tone'),
    generateBtn: document.getElementById('generateBtn'),
    resultArea: document.getElementById('resultArea'),
    captionText: document.getElementById('captionText'),
    charCounter: document.getElementById('charCounter'),
    hashtagContainer: document.getElementById('hashtagContainer'),
    copyCaptionBtn: document.getElementById('copyCaptionBtn'),
    copyAllBtn: document.getElementById('copyAllBtn'),
    dailyLimit: document.getElementById('dailyLimit'),
    settingsBtn: document.getElementById('settingsBtn')
  };

  // 1. Load preferences and last image
  const settings = await chrome.storage.sync.get(['defaultPlatform', 'defaultTone', 'openaiApiKey']);
  const local = await chrome.storage.local.get(['lastSelectedImage', 'dailyUsage', 'lastUsedDate']);

  if (settings.defaultPlatform) elements.platform.value = settings.defaultPlatform;
  if (settings.defaultTone) elements.tone.value = settings.defaultTone;
  if (local.lastSelectedImage) elements.imagePreview.src = local.lastSelectedImage;

  // 2. Initialize Daily Limit
  const today = new Date().toDateString();
  let usage = local.lastUsedDate === today ? (local.dailyUsage || 0) : 0;
  updateUsageDisplay(usage);

  // 3. Platform change listener for character counter
  elements.platform.addEventListener('change', () => {
    updateCharCounter();
  });

  elements.captionText.addEventListener('input', () => {
    updateCharCounter();
  });

  // 4. Generate Button
  elements.generateBtn.addEventListener('click', async () => {
    if (usage >= 5) {
      alert("Daily limit reached! Please upgrade to Pro for unlimited captions.");
      return;
    }

    const platform = elements.platform.value;
    const tone = elements.tone.value;
    const imageUrl = elements.imagePreview.src;

    elements.generateBtn.disabled = true;
    elements.generateBtn.innerText = "Generating...";
    
    try {
      let resultCaption = "";
      if (settings.openaiApiKey) {
        // Use OpenAI
        const response = await chrome.runtime.sendMessage({
          action: "generateWithOpenAI",
          data: {
            apiKey: settings.openaiApiKey,
            platform,
            tone,
            imageUrl
          }
        });

        if (response.success) {
          resultCaption = response.caption;
        } else {
          console.warn("OpenAI failed, falling back to templates:", response.error);
          resultCaption = getTemplateCaption(platform, tone);
        }
      } else {
        // Use Template Engine
        resultCaption = getTemplateCaption(platform, tone);
      }

      // Process result
      elements.captionText.value = resultCaption;
      elements.resultArea.classList.remove('hidden');
      
      // Generate Hashtags (from bank)
      generateHashtagChips(tone);
      
      updateCharCounter();

      // Increment Usage
      usage++;
      await chrome.storage.local.set({ dailyUsage: usage, lastUsedDate: today });
      updateUsageDisplay(usage);

    } catch (error) {
      console.error(error);
      alert("An error occurred during generation.");
    } finally {
      elements.generateBtn.disabled = false;
      elements.generateBtn.innerText = "Generate Caption";
    }
  });

  // 5. Copy Buttons
  elements.copyCaptionBtn.addEventListener('click', () => {
    copyToClipboard(elements.captionText.value, elements.copyCaptionBtn);
  });

  elements.copyAllBtn.addEventListener('click', () => {
    const allText = `${elements.captionText.value}\n\n${currentHashtags.join(' ')}`;
    copyToClipboard(allText, elements.copyAllBtn);
  });

  // 6. Settings Button
  elements.settingsBtn.addEventListener('click', () => {
    chrome.runtime.openOptionsPage();
  });

  // Helper Functions
  function updateUsageDisplay(count) {
    elements.dailyLimit.innerText = `Daily Free: ${5 - count} / 5`;
  }

  function updateCharCounter() {
    const platform = elements.platform.value;
    const limit = PLATFORM_LIMITS[platform];
    const current = elements.captionText.value.length;
    elements.charCounter.innerText = `${current} / ${limit}`;
    
    if (current > limit) {
      elements.charCounter.style.color = "#ff4d4d";
    } else {
      elements.charCounter.style.color = "#B0B0B0";
    }
  }

  function getTemplateCaption(platform, tone) {
    const list = CAPTION_TEMPLATES[platform][tone];
    return list[Math.floor(Math.random() * list.length)];
  }

  function generateHashtagChips(tone) {
    const bank = HASHTAG_BANK[tone];
    // Randomly pick 15-20 hashtags
    const shuffled = [...bank].sort(() => 0.5 - Math.random());
    currentHashtags = shuffled.slice(0, 20).map(h => `#${h}`);
    
    renderHashtags();
  }

  function renderHashtags() {
    elements.hashtagContainer.innerHTML = '';
    currentHashtags.forEach((tag, index) => {
      const chip = document.createElement('div');
      chip.className = 'hashtag-chip';
      chip.innerHTML = `${tag} <span class="remove" data-index="${index}">×</span>`;
      elements.hashtagContainer.appendChild(chip);
    });

    // Add remove listeners
    document.querySelectorAll('.hashtag-chip .remove').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const idx = e.target.getAttribute('data-index');
        currentHashtags.splice(idx, 1);
        renderHashtags();
      });
    });
  }

  function copyToClipboard(text, button) {
    navigator.clipboard.writeText(text).then(() => {
      const originalText = button.innerText;
      button.innerText = "Copied!";
      setTimeout(() => {
        button.innerText = originalText;
      }, 2000);
    });
  }
});
