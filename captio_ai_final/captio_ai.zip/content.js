// Content script for Captio AI
// Currently image source is captured via background context menu
console.log("Captio AI content script loaded.");
