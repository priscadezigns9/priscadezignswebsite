# AI AGENT MASTER DATABASE (2026)

This database tracks high-fidelity AI agents capable of replacing or augmenting human roles across business sectors.

## Sector: Sales & Business Development
| Agent Name | Job Role Replacement | Provider | Key Features | Pricing Model | Implementation |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Alice** | SDR / Lead Gen | 11x.ai | Autonomous outbound, research, and personalization. | Outcome-based / SaaS | [11x.ai](https://11x.ai) |
| **Apollo AI** | Sales Prospecting | Apollo.io | Integrated database with AI-driven email sequencing and lead scoring. | Per seat / Tiered | [Apollo.io](https://apollo.io) |
| **Reggie** | Content/Sales Copy | Reggie.ai | AI-driven content generation for sales sequences. | Subscription | [Reggie.ai](https://reggie.ai) |

## Sector: Software Engineering
| Agent Name | Job Role Replacement | Provider | Key Features | Pricing Model | Implementation |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Devin** | Software Engineer | Cognition | Autonomous coding, debugging, and project deployment. | Performance/Usage | [Cognition AI](https://cognition-labs.com) |
| **Sweep** | Junior Developer | Sweep.dev | Turns GitHub issues into pull requests autonomously. | Usage-based | [Sweep.dev](https://sweep.dev) |
| **OpenDevin** | Open Source SWE | Community | Community-driven autonomous software engineering agent. | Free/Open Source | [GitHub](https://github.com/OpenDevin/OpenDevin) |

## Sector: Customer Service & Experience
| Agent Name | Job Role Replacement | Provider | Key Features | Pricing Model | Implementation |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Sierra** | CS Representative | Sierra AI | High-fidelity, conversational autonomous customer service. | Enterprise SaaS | [Sierra.ai](https://sierra.ai) |
| **Fin** | Support Agent | Intercom | Integrated AI agent for Intercom users; resolves 50%+ of queries. | Per resolution | [Intercom](https://intercom.com) |
| **Decibel** | Voice CS Agent | Decibel | Low-latency, high-fidelity voice AI for phone support. | Usage (Minutes) | [Decibel.ai](https://decibel.ai) |

## Sector: Legal & Compliance
| Agent Name | Job Role Replacement | Provider | Key Features | Pricing Model | Implementation |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Harvey** | Paralegal / Legal Researcher | Harvey AI | Contract analysis, due diligence, and case law research. | Enterprise | [Harvey.ai](https://harvey.ai) |
| **CoCounsel** | Legal Assistant | Casetext | Legal research, document review, and deposition prep. | Subscription | [Casetext](https://casetext.com) |
| **Spellbook** | Contract Specialist | Spellbook | AI contract drafting and review inside MS Word. | Per Seat | [Spellbook.legal](https://spellbook.legal) |

## Sector: Human Resources (HR)
| Agent Name | Job Role Replacement | Provider | Key Features | Pricing Model | Implementation |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Olivia** | Recruitment Assistant | Paradox | Autonomous scheduling, screening, and candidate engagement. | Enterprise | [Paradox.ai](https://paradox.ai) |
| **Eightfold AI** | Talent Strategist | Eightfold.ai | AI-driven talent management and skill-gap analysis. | Enterprise | [Eightfold.ai](https://eightfold.ai) |
| **Sana AI** | Training & Onboarding | Sana Labs | Personalized employee training and knowledge management. | Subscription | [Sanalabs.com](https://sanalabs.com) |

## Sector: Finance & Operations
| Agent Name | Job Role Replacement | Provider | Key Features | Pricing Model | Implementation |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Vic.ai** | Accounts Payable Clerk | Vic.ai | Autonomous invoice processing and bill payment. | Per Invoice | [Vic.ai](https://vic.ai) |
| **Ramp AI** | Expense Manager | Ramp | Automated expense categorization and policy enforcement. | Platform-based | [Ramp.com](https://ramp.com) |
| **Bill.com AI** | Bookkeeper | Bill.com | Intelligent workflows for AR/AP and payments. | Subscription/Usage | [Bill.com](https://bill.com) |

## Sector: Marketing & Creative
| Agent Name | Job Role Replacement | Provider | Key Features | Pricing Model | Implementation |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Jasper** | Content Marketer | Jasper.ai | Multi-channel content generation with brand voice consistency. | Subscription | [Jasper.ai](https://jasper.ai) |
| **Copy.ai** | Marketing Ops | Copy.ai | Workflow automation for high-volume GTM content. | Tiered | [Copy.ai](https://copy.ai) |
| **AdCreative** | Ad Designer | AdCreative.ai | Autonomous generation of high-conversion ad creatives. | Usage-based | [AdCreative.ai](https://adcreative.ai) |

---
**Status:** Database Initialized (Jun 28, 2026).
**Update Frequency:** On-demand / Weekly.
