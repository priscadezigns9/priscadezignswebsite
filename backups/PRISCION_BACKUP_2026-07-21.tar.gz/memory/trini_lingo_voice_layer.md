# 🇹🇹 Trini Lingo Cultural Voice Layer

**Source:** Wiktionary Glossary of Trinidadian English, Trini-in-Xisle Dictionary, Carnaval.com Trini Lingo — July 2026
**Purpose:** Cultural intelligence layer for Drew voice agent and Prisca Dezigns AI interactions with Caribbean clients.
**Roots:** English Creole + French Creole + Bhojpuri/Hindi + West African languages + Spanish

---

## Dictionary

| Word / Phrase | Meaning |
|---|---|
| **A A! / Eh-Eh!** | exclamation of surprise or disapproval; 'Well, excuse me!' |
| **Ah** | substitute for 'I' |
| **Ah dawg** | a $20 bill |
| **Ah go do fuh yuh** | a threat of revenge or retaliation |
| **Allyuh** | you all / all of you people |
| **Awa** | or what — used at end of sentence for flow e.g. 'yuh wastin muh time, awa?' |
| **Ax** | ask (to ask a question) |
| **Aye-yah-yie** | expression of anticipation or pain |
| **Ass buss** | failed; worn out; out of energy; 'Yuh ass buss!' |
| **Baaboo** | ghost or spirit; used to scare children |
| **Bacchanal** | commotion, wild party, a big fight between neighbours or family |
| **Badjohn / Ba-John** | a bully or tough person |
| **Bad** | used to describe something extremely good; also can mean promiscuous |
| **Bad eye / Cut-eye** | a look of anger, especially from the corner of the eye |
| **Bad lucky** | unlucky, in an unfortunate situation |
| **Bamsee / Boomsee** | buttocks |
| **Bazodee** | light-headed, dazed, crazy [from French abasourdir] |
| **Blight** | cursed, bad omen, bad luck |
| **Bobbol** | illegal activity; especially white-collar crime or political corruption |
| **Bobolee** | effigy of Judas beaten at Easter; also a stupid or gullible person |
| **Bol'face** | brazen, demanding person who speaks without discretion |
| **Bois** | a big heavy stick; to beat someone badly [pronounced 'Bwah'] |
| **Bonx** | to hit or slam; also a fist greeting; derived from 'Bounce' |
| **Boof / Bouff** | to rough someone up or scold them |
| **Break Biche** | to skip duties to go lime; skip school or work |
| **Bredda** | brother |
| **Broughtupcy** | manners, upbringing, decorum |
| **Buljol** | dish made from salted fish, similar to Portuguese Bacalhau |
| **Buh wait nah** | but wait a minute / hold on now |
| **Buss** | burst; also to end a relationship |
| **Buss-up-shot** | a type of flat bread also known as Paratha |
| **Callaloo** | thick green soup made with dasheen leaves, ochro, coconut milk and crab — national dish |
| **Cheups / Steups** | sound made by sucking teeth to express disapproval |
| **Chinkee** | very tiny portions of anything |
| **Chip** | a walking shuffle step done to slower soca tunes at Carnival |
| **Chip-Chip** | small species of bivalve mollusks found on sandy shores |
| **Chook / Jook** | to pierce; also a type of dancing involving hip thrusting |
| **Chupid** | stupid |
| **Chupidee** | a foolish person |
| **Cock-up** | to lay back in a relaxed posture with feet off the ground |
| **Coki-eye** | cross-eyed |
| **Commesse** | confusion associated with arguments, gossip and slander |
| **Corbeaux** | a black vulture [pronounced 'Cobo'] |
| **Coskel / Cosquelle** | overdressed; brightly coloured; overwhelming |
| **Cuff** | hitting someone with a clenched fist |
| **Cut-ass** | a physical beating |
| **Cutlass** | a machete; the everyday tool for yard work in T&T |
| **Cyah** | can't |
| **Da is you?** | is that you? |
| **Dan** | man; used like 'bro' to address a male friend |
| **Dan-dan** | any sharp-looking outfit |
| **Dat** | that |
| **Dat good for yuh** | serves you right |
| **Daz** | that's / that is |
| **De** | the |
| **Dey** | there |
| **Dingolay** | to dance wildly |
| **Doh** | don't |
| **Dong** | down; 'Dongtong' = Downtown |
| **Dotish** | stupid, foolish |
| **Doubles** | sandwich made with saffron bread and curried chick peas; T&T street food staple; no singular form |
| **Douen** | mythological dwarf with backwards-facing feet who lures children into the forest |
| **Dougla** | person of mixed Afro-Trinidadian and Indo-Trinidadian heritage |
| **Doux doux** | sweet; term of endearment in romantic or caring context [from French] |
| **Drevait** | wayward person who likes to knock about [pronounced 'dree-vay'] |
| **Drop** | a ride by car |
| **Duppy** | ghost or spirit |
| **Eh Eh** | expression of disapproval |
| **Eh Heh** | 'is that so?' — usually sarcastic |
| **Ent?** | 'isn't that so?' / 'right?' — used at end of sentence like Spanish '¿no?' |
| **Fadda** | to address another male; also used to exclaim, derived from 'Oh God!' |
| **Fas** | nosy, inquisitive |
| **Fête** | a party; especially Carnival parties [from French] |
| **Fig** | banana |
| **Five-fingers** | star fruit / carambola |
| **Flambeau** | a lighted torch made from a beer bottle filled with kerosene |
| **Frontish** | bold, demanding, loves attention and being in the centre of things |
| **Galvanize** | corrugated iron sheet used for roofing; a very Trini building material |
| **Geera pork** | pork seasoned with roasted cumin (geera) — popular T&T street food |
| **Gyirl / Gyul / Gyal** | girl; 'Aye Gyirl!' = Hey Girl! |
| **Handle** | to take care of something or assist someone; 'he go handle yuh' |
| **Hard-back-man** | a grown, physically matured male |
| **Horn** | to cheat on a partner; be unfaithful |
| **Hops** | small bread bun used for sandwiches |
| **Hoss / Horse** | a good friend or pal |
| **Jagabat / Jammet** | woman of ill repute |
| **Jah-know** | God knows; used when something unexpected occurs |
| **Jumbie** | ghost, spirit, or supernatural being |
| **Kurma** | deep fried sweet dough strips coated in sugar syrup — Indian-Trini sweet |
| **Lagahoo / La Gahoo** | a shape-shifting spirit or jumbie of Trinidadian folklore |
| **Lime / Liming** | to hang out; chilling with friends; 'a lime' = a casual gathering — core social concept |
| **Maco / Macos** | a nosy person; to spy or be nosy; 'Doh maco in meh business' |
| **Mamaguy** | to tease or make fun of someone; to flatter insincerely |
| **Mauvais langue** | bad-talking someone; spreading rumors [from French 'bad tongue'] |
| **Mauby** | a bitter-sweet drink made from mauby bark |
| **Obzokee** | odd-looking, out of place, awkward in appearance |
| **Old-talk** | idle gossip; storytelling; chatting about nothing in particular |
| **Pardner / Sou-sou** | an informal community savings scheme where members contribute weekly |
| **Pelau** | one-pot dish of rice, pigeon peas, and meat in coconut milk — national comfort food |
| **Pholourie** | fried split pea dough balls served with tamarind or mango chutney |
| **Planass** | to slap someone with the flat of a cutlass; a severe scolding |
| **Pothound** | a mixed breed or stray dog; also called 'pot hound' |
| **Provision** | ground provisions (yam, dasheen, eddoe, cassava) — staple root vegetables |
| **Roti** | flatbread; in T&T often refers to a wrap with curry filling |
| **Saga-boy / Sagaboy** | a flashy, well-dressed man who is a charmer |
| **Saheena** | fried dasheen leaf fritters with split pea batter |
| **Shark and bake** | fried shark in a fried bake with pepper sauce — iconic Maracas Beach food |
| **Soca** | soul calypso; the popular music genre of Trinidad and the Caribbean |
| **Sorrel** | hibiscus-based drink popular at Christmas time in T&T |
| **Soucouyant** | a shape-shifting fire spirit that sucks blood at night — T&T folklore |
| **Soiree** | a social gathering or fête, often more formal [from French] |
| **Souse** | pickled pig parts (feet, ears, snout) with cucumbers and lime — popular street food |
| **Tabanca** | the sadness and longing felt after a breakup; lovesickness — very Trini concept |
| **Tanty / Tantie** | aunt; affectionate term for any older woman |
| **Wajang** | a rude, ill-mannered, uncouth person |
| **Whe-whe** | an illegal numbers lottery game popular in Trinidad |
| **Wukkin' up / Wine** | a type of hip-rolling dance move popular at fêtes and Carnival |
| **Zandolee** | a type of small ground lizard native to Trinidad |
| **Cocoa tea** | hot chocolate drink made with locally grown cocoa sticks — a breakfast staple |
| **Baccoo** | a mythological creature said to bring luck or mischief; a small spirit |
| **Black pudding** | blood sausage made with pig blood, rice, and spices — local street food |
| **Pothound** | a mixed breed or stray dog |
| **Blag / Bragging** | boasting; storytelling with exaggeration at a lime |

---

## Key Cultural Concepts for AI Voice Context

- **Lime / Liming** — THE core social concept in T&T. A lime is any casual gathering. You don't 'hang out', you 'lime'.
- **Bacchanal** — Chaos, drama, or a big party. Context determines meaning.
- **Tabanca** — Lovesickness after a breakup. Uniquely Trini — no English equivalent.
- **Ent?** — Most common sentence-ender. Equivalent to 'right?' or Spanish '¿no?'
- **Doubles** — National street breakfast. No singular form — 'one doubles', never 'one double'.
- **Fête** — A party (from French). Carnival fêtes are a cultural institution.
- **Steups / Cheups** — Sucking teeth. Signals disapproval, impatience, or dismissal.
- **Maco** — Nosiness. 'Doh maco' = mind your business.
- **Mamaguy** — Insincere flattery or teasing. 'Yuh maguying me?' = are you for real?
- **Old-talk** — Storytelling gossip at a lime. A respected social art in T&T.
- **Wukkin up / Wine** — The iconic hip-roll dance. Central to Carnival and soca culture.
- **Soucouyant / Lagahoo / Douen / Jumbie** — T&T folklore spirits — deep cultural knowledge.
- **Sou-sou / Pardner** — Community savings group — shows collective financial culture.
- **Shark and Bake** — Iconic Maracas Beach food. A cultural landmark experience.
- **Soca vs Calypso** — Soca = energetic dance music. Calypso = storytelling/political commentary.


---
## Corrections Applied (2026-07-15) — User-Verified Definitions

| Word | Previous (Wrong) | Corrected |
|---|---|---|
| **Tabanca** | Deep emotional frustration/heartbreak | Lovesick / foolishly infatuated — stupid over someone. Can be literal OR sarcastic depending on context. |
| **Doubles** | Referenced as generic dish | National street food of Trinidad. Two baras with channa. No singular form. Cultural touchstone — warmth signal from caller. |
| **Fete** | Formal or semi-formal gathering | A party. Celebratory event, music, food, crowd. Not formal at all. |

These corrections sourced directly from the user (native T&T). Ground truth.
