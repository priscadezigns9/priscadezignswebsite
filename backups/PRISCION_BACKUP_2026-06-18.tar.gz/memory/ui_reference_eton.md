# REFERENCE: Eton College (High-Fidelity UI/UX)
**URL:** https://www.etoncollege.com/
**Captured:** 2026-06-16

### Core Design Logic
- **Dynamic Layering:** Uses overlapping text/image elements and parallax-style transitions to create depth.
- **Traditional Authority + Modern Innovation:** Pairs centuries-old heritage imagery with clean, responsive grid layouts.
- **Typography:** Classic serif headers (Sovereign/Heritage vibe) with high-legibility sans-serif bodies.
- **Content Sharding:** Deep navigation structure that organizes complex information into "Inside/Outside/Outwards" pillars.

### Application for Priscion / Prisca Dezigns
- **Calalloo:** Use the "Heritage Reels" horizontal layer for culinary DNA storytelling.
- **Sole Prestige:** Adapt the "floating" layout for high-end sneaker animations.
- **Quiet Luxury:** Implement the "Sanctuary Engineering" aesthetic using their minimalist, high-contrast visual balance.
- **Priscion Hub:** Use the "Honouring Tradition / Inspiring Change" dual-pane logic to bridge Web2 (Heritage) and Web3 (Innovation).
