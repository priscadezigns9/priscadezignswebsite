---
name: filter-eurusd-from-ny-sniper-signals
description: When the NY Sniper pre-market scan returns EUR/USD signals, exclude them and focus only on approved pairs loaded from references/inputs.json.
metadata:
  presentation:
    title: Auto-Filter EUR/USD Signals
    description: Automatically remove EUR/USD from all NY Sniper scans and focus only on USD/CAD, S&P 500, and Gold.
    what_it_does:
    - Silently filters EUR/USD from every pre-market scan
    - Presents only USD/CAD, S&P 500, and Gold setups
    - Eliminates the need to manually repeat the rule each session
    - Keeps your focus on approved high-fidelity pairs
    try_asking:
    - Filter out EUR/USD from future scans
    - Don't show me EUR/USD trades anymore
    - Focus only on USD/CAD and indices
kind: profile
setup:
  crons:
  - name: NY Sniper Pre-Market Scan
    schedule:
      kind: cron
      expr: 0 8 * * 1-5
      tz: America/Port_of_Spain
    payload:
      kind: system_event
      text: Run the NY Sniper pre-market scan for USD/CAD, S&P 500, and Gold. Filter out any EUR/USD signals and present only valid setups.
    enabled: true
    delete_after_run: false
    description: Daily pre-market scan for trading signals on approved pairs
  - name: Forex Hard Stop Alert
    schedule:
      kind: cron
      expr: 0 10 * * 1-5
      tz: America/Port_of_Spain
    payload:
      kind: system_event
      text: 'Alert: it is now 10:30 AM AST — hard stop time for Forex trades. Close all USD/CAD positions now.'
    enabled: true
    delete_after_run: false
    description: Daily reminder to close all Forex trades at the hard stop time
---
# Filter EUR/USD from NY Sniper Signals

## When to use
The NY Sniper pre-market scan returns multiple asset pairs including EUR/USD. The user has stated a standing rule that EUR/USD is no longer traded. Apply this filter to all future scans automatically so the agent focuses only on the approved trading pairs.

## Procedure
1. Load the approved trading pairs from references/inputs.json (`approved_pairs`).
2. When the NY Sniper scan result includes EUR/USD signals, remove them from the summary.
3. Present only the valid pairs listed in `approved_pairs`.
4. If EUR/USD is the only signal in the scan, report "No valid setups today" and do not recommend any trade.
5. Maintain this rule for all future scans without requiring the user to repeat the instruction.

## Rules
- EUR/USD signals are always filtered out, regardless of entry point, stop loss, or profit potential.
- Do not ask permission to filter—apply the rule silently and only present approved pairs.
- If a scan result lists EUR/USD alongside valid pairs, acknowledge the scan completion but exclude EUR/USD from the trade recommendation.
- The approved pairs list is defined in references/inputs.json under `approved_pairs`.

## Example
**Scan Input:** The system flags multiple signals, including EUR/USD and one or more pairs from the approved list.

**Your Output:** Present only the valid setup(s) from the approved pairs (e.g., "Entry: [price], SL: [price], TP: [price]"). Note that the EUR/USD signal has been filtered per the standing trading rule.

**Result:** The user sees only the actionable trade(s), with no distraction or mental overhead from the banned pair.
