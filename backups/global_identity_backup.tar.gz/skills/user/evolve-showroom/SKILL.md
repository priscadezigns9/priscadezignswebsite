---
name: evolve-showroom
description: Build specialized high-fidelity landing pages for Evolve Mobility across four distinct brand nodes.
---

# Evolve Showroom & Brand Adaptation

## Mission
Build specialized high-fidelity landing pages for Evolve Mobility across four distinct brand nodes, each with a unique narrative and visual "DNA," culminating in a 3D-gallery style showroom.

## Brand DNA & Narrative
- **The Autodrome:** The "Luxury Mechanic." Focus: Raw specs, engineering excellence, luxury performance. Tone: Obsessive, technical, elite.
- **The Tech Scout:** The "Futurist." Focus: Neural processing, software-defined mobility, interface design, battery tech. Tone: Innovative, clinical, high-tech.
- **Verdant Co.:** The "Eco-Architect." Focus: Sustainability, circular economy, gas vs. electric efficiency, the cleaner future. Tone: Professional, regenerative, visionary.
- **Prisca Dezigns:** The "Showstopper." Focus: Lamborghini-style aesthetics, bold visual storytelling, the "Masterpiece." Tone: High-fidelity, artistic, flagship.

## Visual Mandate (The "3D Gallery")
- **Showroom Concept:** Implement a "Walking Through a Gallery" scroll experience. As the user scrolls, the perspective shifts (parallax or 3D transform) to simulate moving through a physical space.
- **Gallery Mode:** Use large, high-contrast imagery (Lamborghini-style photography) once provided.
- **Contact Integration:**
    - **Global:** WhatsApp: 342-4101 | Email: priscadezigns9@gmail.com
    - **Brand Specific:** Link to the specific brand's socials (FB/IG/Threads) but keep the primary contact as the user.

## Technical Execution
- **Navigation:** Add "EV Mobility" or "Showroom" button to The Tech Scout (already exists on Autodrome/Verdant Co).
- **Showroom UI:** Use a dark-mode "Gallery" theme with Ivory highlights to match the elite aesthetic.
- **Interactive specs:** Hover-trigger performance specs (0-100 km/h, Range, Peak Power).
