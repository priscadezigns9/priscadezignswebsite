---
name: senpai
description: "Interactive skill-building and learning platform logic. Use for rapid mastery of new skills with high-fidelity progress tracking and mobile-optimized interfaces."
---

# Senpai

Senpai is the learning arm of the Orcinos Division. It focuses on institutional skill acquisition and rapid mastery through interactive, high-fidelity interfaces.

## Guidelines

- **Mobile-First:** All interfaces must be 100% mobile-optimized with high-fidelity touch targets.
- **Hamburger Navigation:** Use a clean hamburger menu for all navigation on mobile viewports.
- **Progress Tracking:** Maintain high-fidelity telemetry on user learning progress.
- **Zero Simulation:** All learning modules must be functional and provide real-world value.

## Site Structure

- `index.html`: The central hub for skill selection and progress overview.
- `/modules/`: Individual skill mastery paths.
- `/vault/`: Private certification and achievement records.

## UI Mandate

- **Colors:** Clean White, Orcinos Blue (#0071e3), and Deep Black (#1c1c1c).
- **Typography:** Inter for body, Playfair Display for institutional headers.
- **Icons:** Use high-fidelity SVG icons for all touch actions.
